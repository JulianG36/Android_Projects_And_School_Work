package edu.lewisu.cs.julian.quiz1;

import android.app.Activity;
import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;

import android.widget.CheckBox;
import android.widget.CursorAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private CheckBox ch1;
    private CheckBox ch2;
    private CheckBox ch3;
    private TextView label;
    private EditText textBox;
    private RadioButton rb1;
    private RadioButton rb2;
    private Button trueButton;
    private Button falseButton;
    private ImageButton nextButton;
    private ImageButton backButton;
    private TextView questionTextView;
    private int currentIndex = 0;

    private Question[] questions = new Question[]{
            new Question(R.string.question1, true),
            new Question(R.string.question2, true),
            new Question(R.string.question3, true),
            new Question(R.string.question4, false),
    };

    private static final String TAG = "QuizApp";

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (savedInstanceState != null) {
            currentIndex = savedInstanceState.getInt("index");
        }

        trueButton = (Button) findViewById(R.id.true_button);
        falseButton = (Button) findViewById(R.id.false_button);
        nextButton = (ImageButton) findViewById(R.id.next_button);
        backButton = (ImageButton) findViewById(R.id.back_button);
        textBox = (EditText) findViewById(R.id.textBox);
        label = (TextView) findViewById(R.id.textTitle);
        ch1 = (CheckBox) findViewById(R.id.checkbox1);
        ch2 = (CheckBox) findViewById(R.id.checkbox2);
        ch3 = (CheckBox) findViewById(R.id.checkbox3);
        rb1 = (RadioButton) findViewById(R.id.radio_button1);
        rb2 = (RadioButton) findViewById(R.id.radio_button2);
        questionTextView = (TextView) findViewById(R.id.question_text);
        int question = questions[currentIndex].getTextResId();
        questionTextView.setText(question);


        trueButton.setOnClickListener(new TrueButtonClickListener());
        falseButton.setOnClickListener(new FalseButtonClickListener());
        nextButton.setOnClickListener(new NextButtonClickListener());
        backButton.setOnClickListener(new BackButtonClickListener());
        textBox.setOnKeyListener(new TextBoxKey());
        ch1.setOnClickListener(new CheckBoxListener());
        ch2.setOnClickListener(new CheckBoxListener());
        ch3.setOnClickListener(new CheckBoxListener());
        rb1.setOnClickListener(new RadioBoxListener());
        rb2.setOnClickListener(new RadioBoxListener());
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d(TAG, "onStop Called");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d(TAG, "onPause Called");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "OnDestroy Called");
    }

    private class NextButtonClickListener implements View.OnClickListener {
        @Override
        public void onClick(View view) {
            currentIndex = (currentIndex + 1) % questions.length;
            int question = questions[currentIndex].getTextResId();
            questionTextView.setText(question);
        }
    }

    private void checkAnswer(boolean userPressedTrue) {
        boolean answerIsTrue = questions[currentIndex].isAnswerTrue();
        int messageResId = 0;
        if (userPressedTrue == answerIsTrue) {
            messageResId = R.string.correct_toast;
        } else {
            messageResId = R.string.incorrect_toast;
        }
        Toast.makeText(this, messageResId, Toast.LENGTH_SHORT).show();
    }

    private class TrueButtonClickListener implements View.OnClickListener {
        @Override
        public void onClick(View view) {
            checkAnswer(true);
        }
    }

    private class FalseButtonClickListener implements View.OnClickListener {
        @Override
        public void onClick(View view) {
            checkAnswer(false);
        }
    }

    private class BackButtonClickListener implements View.OnClickListener {
        @Override
        public void onClick(View view) {
            if (currentIndex == 0) {
                currentIndex = questions.length - 1;
                int question = questions[currentIndex].getTextResId();
                questionTextView.setText(question);
            } else {
                currentIndex = (currentIndex - 1) % questions.length;
                int question = questions[currentIndex].getTextResId();
                questionTextView.setText(question);
            }

        }
    }

    private class TextBoxKey extends Activity implements View.OnKeyListener {
        @Override
        public boolean onKey(View view, int keyCode, KeyEvent event) {
            if ((event.getAction() == KeyEvent.ACTION_DOWN)&&(keyCode == KeyEvent.KEYCODE_ENTER)) {
                String text = textBox.getText().toString();
                label.setText(text);
                return true;
            }
            return false;
        }
    }
    private class RadioBoxListener implements View.OnClickListener{
        @Override
        public void onClick(View view){
            String text = "";
            if (rb1.isChecked()){
                text = "Hit First Button";
            }
            if (rb2.isChecked()){
                text = "Hit Second Button";
            }
            Context context = getApplicationContext();
            Toast t = Toast.makeText(context, text, Toast.LENGTH_SHORT );
            t.show();
        }
    }
    private class CheckBoxListener implements View.OnClickListener{
        @Override
        public void onClick(View view){
            String text = "";
            if (ch3.isChecked()){
                text = "Yaaay";
            }
            if (ch2.isChecked()){
                text = "Have Fun";
            }
            if (ch1.isChecked()){
                text = "Im Sorry!!";
            }
            Context context = getApplicationContext();
            Toast t = Toast.makeText(context, text, Toast.LENGTH_SHORT );
            t.show();
        }
    }
}

